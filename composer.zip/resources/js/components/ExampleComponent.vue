<template>
        <div id="app">
            <button class="btn btn-primary">Follow</button>
        </div>
</template>


<script>
export default {
    mounted() {
        console.log('component mounted.')
    }
}
</script>
