@component('mail::message')
# Hey Visitor!

This Page is made too practice Vue and Laravel and to build a website like Instagram.

All the best,<br>
Patrick

@endcomponent
