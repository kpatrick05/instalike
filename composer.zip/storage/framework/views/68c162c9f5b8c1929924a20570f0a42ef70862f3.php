<?php $__env->startComponent('mail::message'); ?>
# Hey Visitor!

This Page is made too practice Vue and Laravel and to build a website like Instagram.

All the best,<br>
Patrick

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\FSWD\laravel1\instlike\resources\views/email/welcome-email.blade.php ENDPATH**/ ?>