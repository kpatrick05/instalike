<?php echo e($slot); ?>

<?php /**PATH D:\FSWD\laravel1\instlike\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>